/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica8;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author edu
 */
public class runPractica8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        // TODO code application logic here
        Libro libro = new Libro();
        int opcion = 0;
        Scanner escaner = new Scanner(System.in);
        GestorLibros gl = new GestorLibros();
        
        gl.crearCarpetaYArchivo();
        gl.cargarLibros();
        
        while(opcion != 3){
            System.out.println("Menú principal");
            System.out.println("1. Insertar libros");
            System.out.println("2. Mostrar libros");
            System.out.println("3. Salir");
            System.out.println("Inserte una opcion: ");
            opcion = escaner.nextInt();
            
            switch(opcion)
            {
                case 1 -> 
                {
                    while (opcion != 0){
                        try {
                            escaner.nextLine();
                            System.out.println("Escriba el código del libro: ");
                            libro.setCodigo(escaner.nextLine());
                            System.out.println("Escriba el título del libro: ");
                            libro.setTitulo(escaner.nextLine());
                            System.out.println("Escriba el autor del libro: ");
                            libro.setAutor(escaner.nextLine());
                            System.out.println("Escriba el año del libro: ");
                            libro.setAnio(escaner.nextInt());
                            
                            gl.agregarLibro(new Libro(libro.getCodigo(),libro.getTitulo(),libro.getAutor(),libro.getAnio()));
                            
                            System.out.println("¿Desea agregar otro libro? (0: No, 1: Sí) ");
                            opcion = escaner.nextInt();
                        }
                        catch (InputMismatchException e)
                        {
                            System.out.println("Error al recibir los datos.");
                            escaner.nextLine();
                            System.out.println("¿Desea intentarlo de nuevo? (0: No, 1: Sí) ");
                            opcion = escaner.nextInt();
                        }
                    }
                    gl.guardarLibros();
                }
                case 2 -> 
                {
                    gl.mostrarLibros();
                }
            }
        }
        
    }
    
}
