/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica8;

/**
 *
 * @author edu
 */
public class Libro {

    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the titulo
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * @param titulo the titulo to set
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @param autor the autor to set
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * @return the anio
     */
    public int getAnio() {
        return anio;
    }

    /**
     * @param anio the anio to set
     */
    public void setAnio(int anio) {
        this.anio = anio;
    }
    
    private String codigo;
    private String titulo;
    private String autor;
    private int anio;
    
    public Libro (){
        
    }
    
    public Libro (String c, String t, String a, int an){
        codigo = c;
        titulo = t;
        autor = a;
        anio = an;
    }
    
    public String toFileString(){
        return codigo + "," + titulo + "," + autor + "," + Integer.toString(anio);
    }
    
    @Override
    public String toString(){
        return codigo + "," + titulo + "," + autor + "," + Integer.toString(anio);
    }
}
