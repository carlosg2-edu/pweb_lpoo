/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList; 

/**
 *
 * @author edu
 */
public class GestorLibros {
    ArrayList<Libro> libros = new ArrayList();
    
    String directorio_trabajo = System.getProperty("user.home") + File.separator + "biblioteca";
    File carpeta = new File(directorio_trabajo);
    File archivo = new File(directorio_trabajo + File.separator + "libros.txt");
    
    
    public void crearCarpetaYArchivo(){
        try{
            if (carpeta.mkdir())
            {
                System.out.println("La carpeta biblioteca fue creada.");
                crearCarpetaYArchivo();
            }
            else
            {
                if (carpeta.exists())
                {
                    if (archivo.createNewFile())
                        System.out.println("El archivo libros.txt fue creado.");
                }
            }
        }
        catch (IOException e){
            System.out.println("Error al escribir el archivo libros.txt.");
        }
    }
    
    public void agregarLibro(Libro l){
        libros.add(l);
    }
    
    public void guardarLibros(){
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo)))
        {
            for (Libro  l:libros)
            {
                escritor.write(l.toFileString());
                escritor.newLine();
            }
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Error: el archivo libros.txt no existe.");
        }
        catch(IOException e){
            System.out.println("Error: el archivo no se pudo escribir.");
        }
    }
    
    public void cargarLibros(){
        try (BufferedReader lector = new BufferedReader(new FileReader(archivo)))
        {
            String linea;
            String[] datos;
            while ((linea = lector.readLine()) != null)
            {
                datos = linea.split(",");
                agregarLibro(new Libro(datos[0], datos[1], datos[2], Integer.parseInt(datos[3])));
            }
            if (libros.isEmpty())
                System.out.println("No hay libros registrados.");
        }
        catch(FileNotFoundException e){
            System.out.println("Error: el archivo libros.txt no fue creado.");
        }
        catch(IOException e){
            System.out.println("Error: no se pudo leer el archivo.");
        }
    }
    
    public void mostrarLibros(){
        if (libros.isEmpty())
            System.out.println("No hay libros para mostrar.");
        else
        {
            System.out.println("\nLibros registrados:\n");
            for (Libro l:libros)
            {
                System.out.println("Codigo: " + l.getCodigo());
                System.out.println("Título: " + l.getTitulo());
                System.out.println("Autor: " + l.getAutor());
                System.out.println("Año: " + l.getAnio() + "\n");
                
            }
        }
    }
}
