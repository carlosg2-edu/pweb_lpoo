/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flota;

import java.util.ArrayList;
import java.util.List;
import modelo.Vehiculo;

/**
 *
 * @author edu
 */
public class GestionLogistica {
    List<Vehiculo> flota = new ArrayList();
    
    public void registrarVehiculo (Vehiculo v){
        flota.add(v);
        System.out.println("Vehículo " + v.getId() + " registrado. En proceso de revisión.");
    }
    
    public void despacharFlota(Vehiculo v){
        try{
            v.validarEstado();
            System.out.println("Vehículo " + v.getId() + " válido.");
        }
        catch (Exception e){
            System.out.println(e);
            flota.remove(flota.size() - 1);
        }
    }
}
