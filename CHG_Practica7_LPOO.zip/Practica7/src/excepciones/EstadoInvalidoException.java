/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

/**
 *
 * @author edu
 */
public class EstadoInvalidoException extends Exception{
    public String getIdVehiculo(){
        return IdVehiculo;
    }
    
    private String IdVehiculo;
    
    public EstadoInvalidoException(String idVehiculo, String msg)
    {
        super(msg);
        this.IdVehiculo = idVehiculo;
    }
    
}
