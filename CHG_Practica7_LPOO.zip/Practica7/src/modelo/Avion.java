/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import excepciones.EstadoInvalidoException;

/**
 *
 * @author edu
 */
public class Avion extends Vehiculo implements Volador{

    /**
     * @return the altitudMaxima
     */
    public int getAltitudMaxima() {
        return altitudMaxima;
    }

    /**
     * @param altitudMaxima the altitudMaxima to set
     */
    public void setAltitudMaxima(int altitudMaxima) {
        this.altitudMaxima = altitudMaxima;
    }

    private int altitudMaxima;
    
    @Override
    public void validarEstado() throws EstadoInvalidoException{
        
        if (getNivelCombustible() < 30)
            throw new EstadoInvalidoException(getId(), "el avión " + getId() + " no tiene combustible suficiente.");
    }

    @Override
    public void verificarPlanVuelo(int altitud) {
        if (altitud > altitudMaxima)
            System.out.println("Altitud no viable.");
        else
            System.out.println("Altitud aceptada.");
    }
    
}
