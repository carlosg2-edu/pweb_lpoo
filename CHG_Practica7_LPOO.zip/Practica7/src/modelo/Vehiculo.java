/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import excepciones.EstadoInvalidoException;

/**
 *
 * @author edu
 */
public abstract class Vehiculo {

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    
    /**
     * @param nivelCombustible the nivelCombustible to set
     */
    public void setNivelCombustible(int nivelCombustible) {
        this.nivelCombustible = nivelCombustible;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @return the nivelCombustible
     */
    public int getNivelCombustible() {
        return nivelCombustible;
    }
    private String id;
    private int nivelCombustible;
    
    public abstract void validarEstado() throws EstadoInvalidoException;
    
    
}
