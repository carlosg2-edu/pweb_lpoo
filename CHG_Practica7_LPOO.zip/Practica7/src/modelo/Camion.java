/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import excepciones.EstadoInvalidoException;

/**
 *
 * @author edu
 */
public class Camion extends Vehiculo{
    
    @Override
    public void validarEstado() throws EstadoInvalidoException{
        
        if (getNivelCombustible() < 10)
            throw new EstadoInvalidoException(getId(), "el camión " + getId() + " no tiene combustible suficiente.");
            
    }
    
    
    
}
