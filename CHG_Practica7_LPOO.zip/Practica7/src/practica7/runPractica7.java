 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica7;

import flota.GestionLogistica;
import java.util.ArrayList;
import modelo.Avion;
import modelo.Camion;
import modelo.Vehiculo;

/**
 *
 * @author edu
 */
public class runPractica7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ArrayList<Vehiculo> lista = new ArrayList<Vehiculo>();
        GestionLogistica gl = new GestionLogistica();
        
        Avion av = new Avion();
        Camion cm = new Camion();
        
        av.setAltitudMaxima(9000);
        av.setId("SDJ-49520");
        av.setNivelCombustible(15);
        av.verificarPlanVuelo(5000);
        
        cm.setId("MAC-38572");
        cm.setNivelCombustible(50);
        
        lista.add(av);
        lista.add(cm);
        
        for (Vehiculo vh:lista){
            gl.registrarVehiculo(vh);
            gl.despacharFlota(vh);
        }
        
    }
    
}
