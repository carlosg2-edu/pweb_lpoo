/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica;

/**
 *
 * @author edu
 */


public class Automovil implements AutoCloseable{
    
    public String marca = new String();
    public String modelo;
    public String placa;
    public String color;
    public double gas;
    
    public Automovil(){
        System.out.println("Automovil montado.");
    }
    
    public boolean motorEncendido(double gas){
        
        boolean msg;
        if (gas >= 1) {
            msg = true;
        }
        else
            msg = true;
        return msg;
    }
    
    public void avanzar(){
        System.out.println("Auto avanzando");
    }
    
    public String frenar(){
        return "Auto frenando";
    }
    
    public void apagar(){
        System.out.println("Auto apagado.");
    }
    
    public void acelerar(){
        System.out.println("Acelerando.");
    }
    
    public void decelerar(){
        System.out.println("Reduciendo velocidad.");
    }
     /**
     *
     */
    @Override
    public void close(){
        System.out.println("Auto desmontado.");
    }
}

