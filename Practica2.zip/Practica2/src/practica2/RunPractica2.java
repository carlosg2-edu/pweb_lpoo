/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica2;
import practica.Automovil;
import java.util.Scanner;
/**
 *
 * @author edu
 */
public class RunPractica2 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try(Automovil taurus = new Automovil()){
            taurus.marca = "taurus";
            Scanner myObj = new Scanner(System.in);
            
            System.out.print("Placa: ");
            taurus.placa = myObj.nextLine();
            System.out.print("Modelo: ");
            taurus.modelo = myObj.nextLine();
            System.out.print("Color: ");
            taurus.color = myObj.nextLine();
            System.out.print("Cantidad de gasolina (en litros): ");
            taurus.gas = myObj.nextDouble();
            
            System.out.print("El automovil " + taurus.marca + ", modelo " + taurus.modelo + ", de placa " + taurus.placa + ", tiene ");
            System.out.print(taurus.gas);
            System.out.println(" litros de gasolina.");
                    
            System.out.println("Auto encendido: " + taurus.motorEncendido(taurus.gas));
            taurus.avanzar();
            taurus.acelerar();
            taurus.decelerar();
            System.out.println(taurus.frenar());
            taurus.apagar();
        }
        
    }
    
}
