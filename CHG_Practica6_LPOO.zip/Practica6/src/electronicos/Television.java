/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electronicos;

import componentes.Electronics;
import componentes.IElectricComp;

/**
 *
 * @author edu
 */
public class Television extends Electronics implements IElectricComp{

    public Television(String marca, String modelo) {
        super(marca, modelo);
    }
    
    @Override
    public void powerOn() {
        if (estado)
            System.out.println("La televisión ya está encendida.");
        else
        {
            estado = true;
            System.out.println("Televisión encendida.");
        }
    }

    @Override
    public void powerOff() {
        if (estado)
        {
            estado = false;
            System.out.println("Televisión apagada.");
        }
        else
            System.out.println("La televisión ya está apagada.");
        
    }

    public void newChannel(int chnl) {
        System.out.println("Sintonizando el canal: " + chnl);
    }

    @Override
    public void bajarVolumen(int cambio_vol) {
        if (vol - cambio_vol >= 0){
            vol -= cambio_vol;
        }
        else{
            vol = 0;
        }
        System.out.println("Volumen: " + vol);
    }

    @Override
    public void subirVolumen(int cambio_vol) {
        if (vol + cambio_vol <= 15){
            vol += cambio_vol;
        }
        else{
            vol = 15;
        }
        System.out.println("Volumen: " + vol);
    }
    
}
