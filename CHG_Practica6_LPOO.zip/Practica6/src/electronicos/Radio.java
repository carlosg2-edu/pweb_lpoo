/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electronicos;

import componentes.Electronics;
import componentes.IElectricComp;

/**
 *
 * @author edu
 */
public class Radio extends Electronics implements IElectricComp{

    public Radio(String marca, String modelo) {
        super(marca, modelo);
    }

    @Override
    public void powerOn() {
        if (estado)
            System.out.println("La radio está encendida.");
        else
        {
            estado = true;
            System.out.println("Radio encendida.");
        }
    }

    @Override
    public void powerOff() {
        if (estado)
        {
            estado = false;
            System.out.println("Radio apagada.");
        }
        else
            System.out.println("La radio está apagada.");
        
    }

    public void newChannel(double station){
        System.out.println("Sintonizando la estación: " + station);
    }

    @Override
    public void bajarVolumen(int cambio_vol) {
        if (vol - cambio_vol >= 0){
            vol -= cambio_vol;
        }
        else{
            vol = 0;
        }
        System.out.println("Volumen: " + vol);
    }

    @Override
    public void subirVolumen(int cambio_vol) {
        if (vol + cambio_vol <= 15){
            vol += cambio_vol;
        }
        else{
            vol = 15;
        }
        System.out.println("Volumen: " + vol);
    }
    
}
