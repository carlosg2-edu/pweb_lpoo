/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electronicos;

import componentes.Electronics;
import componentes.IFuncionesAritmeticas;

/**
 *
 * @author edu
 */
public class Calculadora extends Electronics implements IFuncionesAritmeticas{

    public Calculadora(String marca, String modelo) {
        super(marca, modelo);
    }
    
    
    
    @Override
    public void powerOn() {
        if (estado) 
        {
            System.out.println("La calculadora ya está encendida.");
        } 
        else 
        {
            estado = true;
            System.out.println("Calculadora encendida.");
        }
    }

    @Override
    public void powerOff() {
        if (estado)
        {
            estado = false;
            System.out.println("Calculadora apagada.");
        }
        else
        {
            System.out.println("La calculadora ya está apagada.");
        }
    }

    @Override
    public long factorial(long num) {
        if (num == 0)   
            return 1;
        else if (num < 0)
            return 0;
        return num * factorial(num-1);
    }

    @Override
    public double suma(double num1, double num2) {
        return num1 + num2;
    }

    @Override
    public long suma(long num1, long num2) {
        return num1 + num2;
    }
    
    @Override
    public double resta (double num1, double num2){
        return num1 - num2;
    }
    
    @Override
    public long resta (long num1, long num2){
        return num1 - num2;
    }
}
