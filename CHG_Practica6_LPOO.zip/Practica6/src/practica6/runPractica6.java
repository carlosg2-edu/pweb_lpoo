/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica6;

import componentes.Electronics;
import electronicos.Calculadora;
import electronicos.Computadora;
import electronicos.Radio;
import electronicos.Television;
import java.util.ArrayList;

/**
 *
 * @author edu
 */
public class runPractica6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i;
        Computadora comp;
        comp = new Computadora("Acer","Aspire");
        Calculadora calc;
        calc = new Calculadora ("MiniCal", "34-ESD");
        Television tv;
        tv = new Television("Euphoria", "MNS31");
        Electronics elc;
        elc = new Computadora ("Seph", "Renovve");
        Radio r;
        r = new Radio("Sennheiser", "VLM203");
        
        comp.powerOff();
        comp.powerOn();
        System.out.println("Marca: " + comp.mostrarMarca());
        System.out.println("Modelo: " + comp.mostrarModelo());
        System.out.println(9 + " + " + 8 + " = " + comp.suma(9, 8));
        comp.powerOff();
        
        calc.powerOn();
        System.out.println("Marca: " + calc.mostrarMarca());
        System.out.println("Modelo: " + calc.mostrarModelo());
        System.out.println(30 + " - " + 8.5 + " = " + calc.resta(30, 8.5));
        System.out.println("4! = " + calc.factorial(4));
        calc.powerOff();
        
        tv.powerOn();
        tv.newChannel(9);
        System.out.println("Marca: " + tv.mostrarMarca());
        System.out.println("Modelo: " + tv.mostrarModelo());
        tv.subirVolumen(7);
        tv.bajarVolumen(2);
        tv.powerOff();
        
        elc.powerOff();
        elc.powerOn();
        System.out.println("Marca: " + elc.mostrarMarca());
        System.out.println("Modelo: " + elc.mostrarModelo());
        elc.powerOn();
        elc.powerOff();
        
        r.powerOn();
        System.out.println("Marca: " + r.mostrarMarca());
        System.out.println("Modelo: " + r.mostrarModelo());
        r.newChannel(97.6);
        r.bajarVolumen(1);
        r.subirVolumen(9);
        r.powerOff();
        
        ArrayList<Electronics> al = new ArrayList<Electronics>();
        
        al.add(calc);
        al.add(comp);
        al.add(tv);
        al.add(elc);
        al.add(r);
        
        for (i = 0; i < al.size(); i++){
            System.out.println(al.get(i));
            System.out.println(al.listIterator(i));
        }
        
        for (Electronics  em:al){
            em.powerOn();
            em.powerOff();
        }
    }
    
}
