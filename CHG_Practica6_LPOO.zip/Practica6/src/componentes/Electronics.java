/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package componentes;

/**
 *
 * @author edu
 */
public abstract class Electronics{
    private String marca;
    private String modelo;
    
    public Electronics(String marca, String modelo){
        this.marca = marca;
        this.modelo = modelo;
    }
    
    protected boolean estado = false;
    protected int vol = 0;
    
    public String mostrarMarca(){
        return marca;
    }
    
    public String mostrarModelo(){
        return modelo;
    }
    
    public abstract void powerOn();
    public abstract void powerOff();
    
}
