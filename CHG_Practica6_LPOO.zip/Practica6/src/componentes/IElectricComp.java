/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package componentes;

/**
 *
 * @author edu
 */
public interface IElectricComp {
    
    public void bajarVolumen(int cambio_vol);
    public void subirVolumen(int cambio_vol);
}
