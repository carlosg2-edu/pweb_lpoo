/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package componentes;

/**
 *
 * @author edu
 */
public interface IFuncionesAritmeticas {
    public long factorial(long num);
    public double suma(double num1, double num2);
    public long suma(long num1, long num2);
    public double resta(double num1, double num2);
    public long resta(long num1, long num2);
}
