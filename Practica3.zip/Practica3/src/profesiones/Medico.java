/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package profesiones;

import personas.Persona;

/**
 *
 * @author edu
 */
public class Medico extends Persona {
    private String cedula;
    private int clinica;
    private boolean ocupado = false;
    
    
    public String consultas(){
        ocupado = true;
        return "Personas consultando.";
    }

    /**
     * @return the cedula
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * @param cedula the cedula to set
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * @return the clinica
     */
    public int getClinica() {
        return clinica;
    }

    /**
     * @param clinica the clinica to set
     */
    public void setClinica(int clinica) {
        this.clinica = clinica;
    }

    /**
     * @return the ocupado
     */
    public String isOcupado() {
        if(ocupado){
            return "El médico está ocupado.";
        }
        return "El médico está disponible.";
    }
    
    public String pacienteAtendido(){
        if (ocupado){
            ocupado = false;
            return "Una consulta ha finalizado.";
        }
        return isOcupado();
    }
    
    
}
