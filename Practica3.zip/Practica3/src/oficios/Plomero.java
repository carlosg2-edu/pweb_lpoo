/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oficios;

import personas.Persona;

/**
 *
 * @author edu
 */
public class Plomero extends Persona{
    private String calle_pedido;
    private boolean gotera_arreglada = false;
    public String arreglaGotera()
    {
        gotera_arreglada = true;
        return "Plomero arregla gotera.";
    }
    
    public String revisarGotera(){
        if (gotera_arreglada){
            return "Gotera arreglada.";
        }
        return "La gotera aún no está arreglada.";
        
    }

    /**
     * @return the calle_pedido
     */
    public String getCalle_pedido() {
        return calle_pedido;
    }

    /**
     * @param calle_pedido the calle_pedido to set
     */
    public void setCalle_pedido(String calle_pedido) {
        this.calle_pedido = calle_pedido;
    }
    
    
}
