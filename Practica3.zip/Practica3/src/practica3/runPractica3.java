
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica3;

import oficios.Plomero;
import personas.Maestro;
import personas.Persona;
import profesiones.Medico;

/**
 *
 * @author edu
 */
public class runPractica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Persona p = new Persona();
        Medico md = new Medico();
        Maestro ms = new Maestro();
        Plomero pl = new Plomero();
        
        p.setNombre("Juanito Alimaña");
        p.setEdad(25);
        p.dir = "Calle falsa 123";
        
        md.setNombre("Marcos López");
        md.setEdad(40);
        md.setClinica(7);
        md.setCedula("245MLEFJGMANL86");
        md.dir = "Pueblo Entre Nosotros Caminamos Animados #293";
        
        ms.setNombre("José Méndez");
        ms.setEdad(28);
        ms.setMatricula(53823);
        ms.setAula("3-C");
        ms.dir = "Lomas de los Salinas #732D";
        
        pl.setNombre("Paco Dominguez");
        pl.setEdad(33);
        pl.setCalle_pedido("Santa Trinidad #149");
        pl.dir = "Rey de California #131";
        
        System.out.println("La persona de nombre " + p.getNombre() + " tiene " + p.getEdad() + " años y vive en " + p.dir + ".\n");
        
        System.out.println("El médico de nombre " + md.getNombre() + " con cédula " + md.getCedula() + " tiene " + md.getEdad() + " años y vive en " + md.dir + ".");
        System.out.println("El médico " + md.getNombre() + " atiende a pacientes en la clínica " + md.getClinica() + "en su consultorio.");
        System.out.println(md.isOcupado());
        System.out.println(md.consultas());
        System.out.println(md.isOcupado());
        System.out.println(md.pacienteAtendido());
        System.out.println(md.isOcupado() + "\n");
        
        System.out.println("El maestro de nombre " + ms.getNombre() + ", con matrícula " + ms.getMatricula() + ", tiene " + ms.getEdad() + " años y vive en " + md.dir + ".");
        System.out.println("El maestro " + ms.getNombre() + " está impartiendo clases en el aula " + ms.getAula() + ".");
        ms.enseñar();
        System.out.println("");
        
        System.out.println("El plomero de nombre " + pl.getNombre() + " tiene " + pl.getEdad() + " años y trabaja en " + pl.dir + ".");
        System.out.println("El plomero " + pl.getNombre() + " tiene un encargo en la calle " + pl.getCalle_pedido() + ".");
        System.out.println(pl.revisarGotera());
        System.out.println(pl.arreglaGotera());
        System.out.println(pl.revisarGotera());
        
    }
    
}
