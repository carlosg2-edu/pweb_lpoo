/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Model;

import java.sql.*;


/**
 *
 * @author edu
 */
public class Contacto {

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the celular
     */
    public String getCelular() {
        return celular;
    }

    /**
     * @param celular the celular to set
     */
    public void setCelular(String celular) {
        this.celular = celular;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the email address.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the email address to set.
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    private String nombre;
    private String telefono;
    private String celular;
    private String direccion;
    private String correo;
    
    //Todos los datos que interactuan con la base de datos
    
    public void addContacto(String username, String password){
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/", username, password);
            Statement stmt = conn.createStatement();
            stmt.execute("CREATE DATABASE IF NOT EXISTS web");
            stmt.execute("USE web");
            stmt.execute("""
                         CREATE TABLE IF NOT EXISTS contactos 
                         (nombre VARCHAR(100),
                         telefono LONG,
                         celular LONG,
                         direccion VARCHAR(300),
                         correo VARCHAR(100))""");
            stmt.executeUpdate("INSERT INTO contactos(nombre, telefono, celular, direccion, correo) VALUES ('"+nombre+"',"+telefono+","+celular+",'"+direccion+"','"+correo+"')");
            conn.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        //Conexión de la base de datos
        
    }
}
