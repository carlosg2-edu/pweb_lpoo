/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DB;

import java.sql.*;

/**
 *
 * @author edu
 */
public class DBConnection {
    public static void main(String [] args){
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql//localhost:3306/contactos", "root", "4258");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("");
            conn.close();
        }
        catch(SQLException e){

        }
    }
}
