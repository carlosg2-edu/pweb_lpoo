/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica11.singleton;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author edu
 */
public class NotificationLogger {
    private static NotificationLogger logger = null;
    List<String> logs = new ArrayList<String>();
    private NotificationLogger(){
    }
    
    public static synchronized NotificationLogger getInstance(){
        if (logger == null)
            logger = new NotificationLogger();
        return logger;
    }
    
    public synchronized void log (String msg)
    {
        logs.add(msg);
        System.out.println("[LOG] " + msg);
    }
    
    public List<String> getLogs() {
        return logs;
    }
    
}
