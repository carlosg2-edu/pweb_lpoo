/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica11.thread;

import practica11.factory.NotificationFactory;
import practica11.model.Notification;
import practica11.singleton.NotificationLogger;

/**
 *
 * @author edu
 */
public class NotificationWorker extends Thread implements Runnable{
    private String tipo;
    private String mensaje;
    private String destinatario;
    
    public NotificationWorker(String tipo, String destinatario, String mensaje) {
        this.tipo = tipo;
        this.destinatario = destinatario;
        this.mensaje = mensaje;
    }

    
    @Override
    public void run() {
        Notification n = NotificationFactory.create(tipo, mensaje);
        n.send(destinatario);
        NotificationLogger.getInstance().log(mensaje);
    }
    
}
