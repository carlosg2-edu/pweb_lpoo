/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package practica11.model;

/**
 *
 * @author edu
 */
public interface Notification {
    public void send(String destinatario);
    public String getType();
}
