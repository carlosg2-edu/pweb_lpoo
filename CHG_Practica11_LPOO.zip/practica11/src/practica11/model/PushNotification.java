/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica11.model;

/**
 *
 * @author edu
 */
public class PushNotification implements Notification{
    
    private String mensaje;
    public PushNotification (String msg){
        mensaje = msg;
    }
    
    @Override
    public void send(String destinatario) {
        System.out.println("Enviando notificación push a " + destinatario + " ...");
    }

    @Override
    public String getType() {
        return "PUSH";
    }
    
}
