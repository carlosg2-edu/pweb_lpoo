/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica11.model;

/**
 *
 * @author edu
 */
public class SMSNotification implements Notification{
    
    private String mensaje;
    public SMSNotification (String msg){
        mensaje = msg;
    }
    @Override
    public void send(String destinatario) {
        System.out.println("Enviando SMS a " + destinatario + " ...");
    }

    @Override
    public String getType() {
        return "SMS";
    }
    
}
