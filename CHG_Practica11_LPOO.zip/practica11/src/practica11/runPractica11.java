/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica11;

import practica11.singleton.NotificationLogger;
import practica11.thread.NotificationWorker;

/**
 *
 * @author edu
 */
public class runPractica11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException{
        
        NotificationWorker h1 = new NotificationWorker("SMS", "8201928312", "Buenos días.");
        NotificationWorker h2 = new NotificationWorker("push", "Marcos", "Aquí tienes los detalles del encargo");
        NotificationWorker h3 = new NotificationWorker("email", "alguien@ejemplo.com", "Buenas tardes.");
        NotificationWorker h4 = new NotificationWorker("push", "César", "Muchas gracias.");
        NotificationWorker h5 = new NotificationWorker("SMS", "8201928312", "Buenas noches.");
        
        h1.run();
        h1.join(1000);
        h2.run();
        h2.join(1000);
        h3.run();
        h3.join(1000);
        h4.run();
        h4.join(1000);
        h5.run();
        h5.join(1000);
        
        NotificationLogger.getInstance().getLogs().forEach(System.out::println);
        // TODO code application logic here
    }
    
}
