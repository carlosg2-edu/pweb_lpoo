/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica11.factory;

import practica11.model.EmailNotification;
import practica11.model.Notification;
import practica11.model.PushNotification;
import practica11.model.SMSNotification;

/**
 *
 * @author edu
 */
public class NotificationFactory{
    
    public static Notification create(String tipo, String msg){
        tipo = tipo.toUpperCase();
        if(tipo.equalsIgnoreCase("SMS")){
            return new SMSNotification(msg);
        }
        else if (tipo.equalsIgnoreCase("PUSH")){
            return new PushNotification(msg);
        }
        else if (tipo.equalsIgnoreCase("EMAIL")){
            return new EmailNotification(msg);
        }
        else{
            throw new IllegalArgumentException ("\nError: argumento no válido.\n");
        }
    }
    
}
