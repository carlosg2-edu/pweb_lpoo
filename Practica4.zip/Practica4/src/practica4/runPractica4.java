/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4;

import aereo.Avion;
import aereo.Helicoptero;
import aereo.TransporteAereo;
import terrestre.Automovil;
import terrestre.TransporteTerrestre;
import transportes.Transporte;

/**
 *
 * @author edu
 */
public class runPractica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Transporte trA = new TransporteAereo("Boeing", 350);
        TransporteAereo trA1 = new TransporteAereo("Airboss",400);
        Avion av = new Avion("Mexicana", 300);
        Helicoptero hl = new Helicoptero("Lapsi", 8);
        TransporteTerrestre trT = new TransporteTerrestre("Dina", 89);
        Automovil am = new Automovil("Bengali", 4);
        
        trA.mostrarInfo();
        trA.mover();
        
        trA1.mostrarInfo();
        trA1.mover();
        System.out.println(trA1.volar());
        
        av.mostrarInfo();
        av.mover();
        System.out.println(av.volar());
        
        hl.mostrarInfo();
        hl.mover();
        hl.ascender();
        hl.descender();
        
        trT.mostrarInfo();
        trT.mover();
        trT.acelerar();
        trT.decelerar();
        trT.frenar();
        
        am.mostrarInfo();
        am.mover();
        am.acelerar();
        am.decelerar();
        am.frenar();
    }
    
}
