/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transportes;

/**
 *
 * @author edu
 */
public class Transporte {
    
    String marca;
    int capacidad;
    
    public Transporte(String marca, int capacidad){
        this.marca = marca;
        this.capacidad = capacidad;
    }
    
    public void mover() {
        System.out.println("Transporte en movimiento.");
    }
    
    public void mostrarInfo(){
        System.out.println("Marca: " + marca);
        System.out.println("Capacidad: " + capacidad);   
    }
    
    
    
}
