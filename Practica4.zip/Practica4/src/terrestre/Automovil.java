/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package terrestre;

/**
 *
 * @author edu
 */
public class Automovil extends TransporteTerrestre {
    
    public Automovil(String marca, int capacidad) {
        super(marca, capacidad);
    }
    
    @Override
    public void mover(){
        System.out.println("Automóvil en movimiento.");
    }
    @Override    
    public void acelerar(){
        System.out.println("Automóvil acelerando.");
    }
    @Override
    public void decelerar(){
        System.out.println("Automóvil decelerando.");
    }
    @Override
    public void frenar(){
        System.out.println("Automóvil frenado.");
    }
}
