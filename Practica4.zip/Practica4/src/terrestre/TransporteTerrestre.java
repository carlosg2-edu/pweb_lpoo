/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package terrestre;

import transportes.Transporte;

/**
 *
 * @author edu
 */
public class TransporteTerrestre  extends Transporte{
    
    public TransporteTerrestre(String marca, int capacidad) {
        super(marca, capacidad);
    }
    
    @Override
    public void mover() {
        System.out.println("Transporte terrestre en movimiento.");
    }
    
    public void acelerar(){
        System.out.println("Transporte terrestre acelerando.");
    }
    
    public void decelerar(){
        System.out.println("Transporte terrestre decelerando.");
    }
    
    public void frenar(){
        System.out.println("Transporte terrestre frenado.");
    }
    
    
    
}
