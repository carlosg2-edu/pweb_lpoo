/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aereo;

/**
 *
 * @author edu
 */
public final class Helicoptero extends TransporteAereo {
    
    public Helicoptero(String marca, int capacidad) {
        super(marca, capacidad);
    }
    
    @Override
    public void mover(){
        System.out.println("Helicóptero en movimiento.");
    }
    
    public void ascender(){
        System.out.println("Helicóptero ascendiendo...");
    }
    
    public void descender(){
        System.out.println("Helicóptero descendiendo...");
    }
}
