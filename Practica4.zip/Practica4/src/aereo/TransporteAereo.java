/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aereo;

import transportes.Transporte;

/**
 *
 * @author edu
 */
public class TransporteAereo extends Transporte{
    
    public TransporteAereo(String marca, int capacidad) {
        super(marca, capacidad);
    }
    
    /**
     pi.*
     */
    @Override
    public void mover() {
        System.out.println("Transporte aéreo en movimiento.");
    }
    public String volar(){
        return "Transporte aéreo volando.";
    }
}
