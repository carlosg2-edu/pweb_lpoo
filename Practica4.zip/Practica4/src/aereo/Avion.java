/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aereo;

/**
 *
 * @author edu
 */
public class Avion extends TransporteAereo{
    
    public Avion(String marca, int capacidad) {
        super(marca, capacidad);
    }
    
    public void aterrizar(){
        System.out.println("Avión aterrizando.");
    }
}
