/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica10;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.lang.ArrayIndexOutOfBoundsException;

/**
 *
 * @author edu
 */
public class runPractica10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        // TODO code application logic here
        int opcion = 0;
        ArrayList<Thread> hilos = new ArrayList();
        Scanner escaner = new Scanner(System.in);
        GestorTareas gt = new GestorTareas();
        var contador_tareas_hiladas = 0;
        int i = 0;
        gt.leerArchivo();
        //gl.crearCarpetaYArchivo();
        //gl.cargarLibros();
        
        while(opcion != 5){
            System.out.println("Menú principal");
            System.out.println("1. Crear tareas");
            System.out.println("2. Mostrar tareas");
            System.out.println("3. Procesar tareas");
            System.out.println("4. Marcar tareas en ejecución como completadas");
            System.out.println("5. Salir");
            System.out.println("Inserte una opcion: ");
            opcion = escaner.nextInt();
            
            switch(opcion)
            {
                case 1 -> 
                {
                    while (opcion != 0){
                        try {
                            escaner.nextLine();
                            gt.agregarTarea();
                            System.out.println("¿Desea agregar otra tarea? (0: No, 1: Sí) ");
                            opcion = escaner.nextInt();
                        }
                        catch (InputMismatchException e)
                        {
                            System.out.println("Error al recibir los datos.");
                            escaner.nextLine();
                            System.out.println("¿Desea intentarlo de nuevo? (0: No, 1: Sí) ");
                            opcion = escaner.nextInt();
                        }
                        gt.guardarArchivo();
                    }
                    //gl.guardarLibros();
                }
                case 2 -> 
                {
                    gt.mostrarTareas();
                }
                
                case 3 ->{
                    while (opcion != 0){
                        try {
                            escaner.nextLine();
                            gt.mostrarTareasPendientes();
                            System.out.println("Seleccione una tarea para procesar (por ID): ");
                            opcion = escaner.nextInt();
                            hilos.add(new ProcesadorTareas(gt.getTaskName(opcion - 1)));
                            gt.setThreadedTaskState(opcion - 1);
                            contador_tareas_hiladas++;
                            System.out.println("¿Desea procesar otra tarea? (0: No, 1: Sí) ");
                            opcion = escaner.nextInt();
                        }
                        catch (Exception e)
                        {
                            System.out.println("Error al recibir los datos.");
                            escaner.nextLine();
                            System.out.println("¿Desea intentarlo de nuevo? (0: No, 1: Sí) ");
                            opcion = escaner.nextInt();
                        }
                        for (i = gt.getThreadedTasksCounter(); i < contador_tareas_hiladas; i++){
                            hilos.get(i).start();
                        }
                        gt.setThreadedTasksCounter(contador_tareas_hiladas);
                        gt.guardarArchivo();
                    }
                }
                
                case 4 ->{
                    for (i = 0; i < hilos.size(); i++){
                        hilos.get(i).interrupt();
                    }
                    
                    hilos.clear();
                    gt.setThreadedTaskClear();
                    gt.guardarArchivo();
                }
            }
        }
        
    }
    
}
