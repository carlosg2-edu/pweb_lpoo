/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

/**
 *
 * @author edu
 */
public class Tarea{

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    private int id;
    private String nombre;
    private String estado;
    
    public Tarea (int ident, String nom, String est){
        id = ident;
        nombre = nom;
        estado = est;
    }
    public Tarea(){
        
    }
    
    @Override
    public String toString(){
        return getId() + "," + getNombre() + "," + getEstado();
    }
    
    public String toFileString(){
        return getId() + "," + getNombre() + "," + getEstado();
    }
}
