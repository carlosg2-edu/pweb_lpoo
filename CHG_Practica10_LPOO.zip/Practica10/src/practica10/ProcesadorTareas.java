/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

/**
 *
 * @author edu
 */
public class ProcesadorTareas extends Thread implements Runnable{

    private String nombre;
    
    public ProcesadorTareas(String nombre){
        this.nombre = nombre;
    }
    
    @Override
    public void run() {
        System.out.println("Iniciando tarea.");
        try
        {
            System.out.println("Ejecutando: " + nombre);
            Thread.sleep(10000);
        }
        catch(InterruptedException e){
            System.out.println("Error.");
        }
    }
    
}
