/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author edu
 */
public class GestorTareas {
    private ArrayList<Tarea> lista = new ArrayList();
    private HashMap<Integer,Tarea> mapa = new HashMap();
    private HashSet<String> set = new HashSet();
    private LinkedList<Tarea> cola = new LinkedList();
    private int contador_tareas_hiladas = 0;
    
    public void setThreadedTasksCounter(int num){
        contador_tareas_hiladas = num;
    }
    
    public int getThreadedTasksCounter(){
        return contador_tareas_hiladas;
    }
    
    public int getTaskId(int i){
        return lista.get(i).getId();
    }
    
    public String getTaskName(int i){
        try{
            return lista.get(i).getNombre();
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Error: número no válido.");
            return null;
        }
    }
    
    public void setThreadedTaskState(int i){
        lista.get(i).setEstado("Ejecutándose");
        mapa.get(i).setEstado("Ejecutándose");
        cola.get(i).setEstado("Ejecutándose");
        
    }
    
    public void setThreadedTaskClear(){
        int i = 0;
        for (i = 0; i < lista.size(); i++){
            if (lista.get(i).getEstado().equalsIgnoreCase("Ejecutándose")){
                set.remove(lista.get(i).getNombre());
                lista.remove(i);
                mapa.remove(i);
                cola.remove(i);
            }
        }
        contador_tareas_hiladas = 0;
    }
    
    File archivo = new File(System.getProperty("user.home") + File.separator + "tareas.txt");
    Scanner escaner = new Scanner(System.in);
    
    public void agregarTarea()
    {
        try{
            Tarea t = new Tarea();
            System.out.println("Escriba la tarea: ");
            t.setNombre(escaner.nextLine());
            if (set.contains(t.getNombre())){
                System.out.println("La tarea '" + t.getNombre() +  "' ya existe.");
            }
            else 
            {
                if (t.getNombre().isEmpty())
                {
                    System.out.println("Error: el nombre está en blanco.");
                }
                else
                {
                    if (lista.isEmpty())
                        t.setId(1);
                    else
                        t.setId(lista.getLast().getId() + 1);
                    t.setEstado("Pendiente");
                    lista.add(new Tarea(t.getId(), t.getNombre(), t.getEstado()));
                    mapa.put(t.getId(), (new Tarea(t.getId(), t.getNombre(), t.getEstado())));
                    set.add(t.getNombre());
                    cola.add(new Tarea(t.getId(), t.getNombre(), t.getEstado()));
                }
            }
        }
        catch(Exception e)
        {
            
        }
    }
    /*It saves every task in the data structures.*/
    public void guardarArchivo()
    {
        if (archivo.exists()){
            try(BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo))){
                for (Tarea t:lista){
                    escritor.write(t.toFileString());
                    escritor.newLine();
                }
            }
            catch(IOException e){
                System.out.println("Error: no se pudo escribir en el archivo tareas.txt.");
            }
        }
        else{
            try
            {
                archivo.createNewFile();
                guardarArchivo();
            }
            catch(IOException e){
                System.out.println("Error: no se pudo crear el archivo tareas.txt.");
            }
        }
    }
    
    public void leerArchivo(){
        try(BufferedReader lector = new BufferedReader(new FileReader(archivo)))
        {
            String linea;
            String[] datos;
            while((linea = lector.readLine()) != null)
            {
                datos = linea.split(",");
                if (datos[2].equalsIgnoreCase("Ejecutándose"))
                    contador_tareas_hiladas++;
                cola.add(new Tarea(Integer.parseInt(datos[0]), datos[1], datos[2]));
                lista.add(new Tarea(Integer.parseInt(datos[0]), datos[1], datos[2]));
                mapa.put(Integer.parseInt(datos[0]), new Tarea(Integer.parseInt(datos[0]), datos[1], datos[2]));
                set.add(datos[1]);
            }
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Error: el archivo tareas.txt no existe.");
        }
        catch(IOException e)
        {
            if (archivo.canRead()) {
            } else {
                System.out.println("Error: el archivo tareas.txt no se puede leer.");
            }
        }
    }
    
    public void mostrarTareas(){
        if (lista.isEmpty()){
            
        }
        else{
            for (Tarea t:lista){
                System.out.println("\nID: " + t.getId());
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Estado: " + t.getEstado() + "\n");
            }
        }
    }
    
    
    public void mostrarTareasPendientes(){
        if (lista.isEmpty()){
            
        }
        else{
            for (Tarea t:lista){
                if (t.getEstado().equalsIgnoreCase("Pendiente")){
                    System.out.println("\nID: " + t.getId());
                    System.out.println("Nombre: " + t.getNombre());
                    System.out.println("Estado: " + t.getEstado() + "\n");
                }
            }
        }
    }
    
    
}
