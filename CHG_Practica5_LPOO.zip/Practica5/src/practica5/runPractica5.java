/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica5;

import Transportes.Automovil;
import Transportes.Avion;
import Transportes.Helicoptero;
import Transportes.Moto;
import java.util.Scanner;

/**
 *
 * @author edu
 */
public class runPractica5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Automovil am;
        Avion av;
        Moto mt;
        Helicoptero hl;
        Scanner escaner = new Scanner(System.in);
        String nombre;
        String placa;
        String color;
        
        System.out.print("Marca del automóvil: ");
        nombre = escaner.nextLine();
        System.out.print("Placa del automóvil: ");
        placa = escaner.nextLine();
        System.out.print("Color del automóvil: ");
        color = escaner.nextLine();
        
        am = new Automovil(nombre,placa,color);
        
        System.out.print("Marca del avión: ");
        nombre = escaner.nextLine();
        System.out.print("Placa del avión: ");
        placa = escaner.nextLine();
        System.out.print("Color del avión: ");
        color = escaner.nextLine();
        
        av = new Avion(nombre,placa,color);
        
        System.out.print("Marca de la motocicleta: ");
        nombre = escaner.nextLine();
        System.out.print("Placa de la motocicleta: ");
        placa = escaner.nextLine();
        System.out.print("Color de la motocicleta: ");
        color = escaner.nextLine();
        
        mt = new Moto(nombre,placa,color);
        
        System.out.print("Marca del helicóptero: ");
        nombre = escaner.nextLine();
        System.out.print("Placa del helicóptero: ");
        placa = escaner.nextLine();
        System.out.print("Color del helicóptero: ");
        color = escaner.nextLine();
        
        hl = new Helicoptero(nombre,placa,color);
        
        am.mostrarMarca();
        am.mostrarPlaca();
        am.mostrarColor();
        am.abrirPuertas();
        am.encenderMotor(5);
        am.cerrarPuertas();

        av.mostrarMarca();
        av.mostrarPlaca();
        av.mostrarColor();
        av.encenderMotor(7);
        av.abrirPuertas();
        av.cerrarPuertas();
        av.volar(7);
        System.out.println(av.acelerar(4));
        System.out.println(av.volar(7));
        av.apagarMotor();

        mt.mostrarMarca();
        mt.mostrarPlaca();
        mt.mostrarColor();
        mt.encenderMotor(9);
        mt.acelerar(9);
        mt.frenar();
        mt.acelerar(7);
        mt.acelerar(5);
        mt.apagarMotor();
        
        hl.mostrarMarca();
        hl.mostrarPlaca();
        hl.mostrarColor();
        hl.abrirPuertas();
        hl.encenderMotor(9);
        hl.cerrarPuertas();
        hl.ascender(9);
        hl.acelerar(7);
        hl.acelerar(5);
        hl.descender();
        hl.apagarMotor();
    }
    
}
