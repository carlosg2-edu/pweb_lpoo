/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Transportes;

/**
 *
 * @author edu
 */
public class Avion extends Vehiculo implements IVolar, ISElectrico, IAceleracion{

    public Avion(String marca, String placa, String color) {
        super(marca, placa, color);
    }

    
    
    @Override
    public void encenderMotor(int gas){
        if (gas > 5)
            System.out.println("Motor del avión encendido.");
        else
            System.out.println("No hay suficiente combustible. El motor no enciende.");
    }

    @Override
    public String volar(int gas) {
        String msg;
        if (gas > 5)
            msg = "Avión volando.";
        else
            msg = "No hay combustible suficiente. El avión no puede volar.";
        return msg;
    }

    @Override
    public void abrirPuertas() {
        System.out.println("Abriendo puertas del avión.");
    }

    @Override
    public void apagarMotor() {
        System.out.println("Avión descendiendo.");
    }

    @Override
    public String acelerar(int gas) {
        if (gas > 5)
            return "Avión acelerando.";
        else
            return "El avión no puede acelerar. Hay poco combustible disponible.";
    }

    @Override
    public void cerrarPuertas() {
        System.out.println("Cerrando puertas del avión.");
    }
    
}
