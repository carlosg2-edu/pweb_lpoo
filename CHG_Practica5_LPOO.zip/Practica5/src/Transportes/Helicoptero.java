/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Transportes;

/**
 *
 * @author edu
 */
public class Helicoptero extends Vehiculo implements ISElectrico,IAceleracion{

    public Helicoptero(String marca, String placa, String color) {
        super(marca, placa, color);
    }

    @Override
    public void encenderMotor(int gas) {
        System.out.println("Motor del helicóptero encendido.");
    }

    @Override
    public void apagarMotor() {
        System.out.println("Motor del helicóptero apagado.");
    }
    
    public void ascender(int gas){
        if (gas > 5)
            System.out.println("Helicoptero ascendiendo.");
        else
            System.out.println("El helicóptero no puede ascender. Hay poco combustible disponible.");
    }
    
    public void descender(){
        System.out.println("Helicoptero descendiendo a tierra.");
    }

    @Override
    public void abrirPuertas() {
        System.out.println("Abriendo puertas del helicóptero.");
    }

    @Override
    public void cerrarPuertas() {
        System.out.println("Cerrando puertas del helicóptero.");
    }

    @Override
    public String acelerar(int gas) {
        if (gas > 5)
            return "La velocidad de las hélices ha aumentado.";
        return "No hay combustible suficiente. Se recomienda descender.";
    }
    
}
