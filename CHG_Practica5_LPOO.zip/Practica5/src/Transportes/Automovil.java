/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Transportes;

/**
 *
 * @author edu
 */
public class Automovil extends Vehiculo implements ISElectrico, IAceleracion{

    public Automovil(String marca, String placa, String color) {
        super(marca, placa, color);
    }

    
    @Override
    public void encenderMotor(int gas){
        if (gas > 5)
            System.out.println("Motor del automovil encendido.");
        else
            System.out.println("No hay gasolina suficiente. El motor no enciende.");
    }

    @Override
    public void abrirPuertas() {
        System.out.println("Abriendo puertas del autómovil.");
    }

    @Override
    public void apagarMotor() {
        System.out.println("Apagando motor. Automovil frenando.");
    }

    @Override
    public String acelerar(int gas) {
        if (gas > 5)
            return "Automóvil acelerando.";
        else
            return "El automóvil no puede acelerar. Hay poca gasolina disponible.";
    }
    
    public void frenar(){
        System.out.println("Automóvil frenando.");
    }
    @Override
    public void cerrarPuertas() {
        System.out.println("Cerrando puertas del automovil.");
    }
    
}
