/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Transportes;

/**
 *
 * @author edu
 */
public class Moto extends Vehiculo implements IAceleracion{

    public Moto(String marca, String placa, String color) {
        super(marca, placa, color);
    }

    @Override
    public void encenderMotor(int gas) {
        if (gas > 5)
            System.out.println("Motor de la moto encendida.");
        else
            System.out.println("No hay suficiente gasolina. La moto no enciende.");
    }

    @Override
    public void apagarMotor() {
        System.out.println("Apagando motor de la motocicleta.");
    }
    
    public void frenar(){
        System.out.println("Moto frenando.");
    }

    @Override
    public String acelerar(int gas) {
        if (gas > 5)
            return "Moto acelerando.";
        else
            return "La moto no puede acelerar. Hay poca gasolina disponible.";
    }
    
    
}
